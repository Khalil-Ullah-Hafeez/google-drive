import socket

# port to listen at
LISTEN_PORT = 8085

# buffer size
BUFFER_SIZE = 1024

# maxmium queue
QUEUE = 1

# create the socket
server_socket = socket.socket( family = socket.AF_INET, type = socket.SOCK_STREAM, proto = 0)

# bind to a port
server_socket.bind( ( '127.0.0.1', LISTEN_PORT ) )

# listen for connections
server_socket.listen( QUEUE )

while True:
    print( 'The server is listening for connections' )
    try:
        # wait for a connection from a client
        client_socket, addr = server_socket.accept()

        # receive data from client
        received_data =  client_socket.recv( BUFFER_SIZE )

        # decode data
        decoded_filename = received_data.decode()

        # open file
        with open(decoded_filename) as file:
            # send file data to client
            client_socket.send( file.read().encode() )

        print( 'Request processed.' )

    except Exception as ex:
        print(ex)    

    # close socket associated with client
    client_socket.close()

# close server socket
server_socket.close()
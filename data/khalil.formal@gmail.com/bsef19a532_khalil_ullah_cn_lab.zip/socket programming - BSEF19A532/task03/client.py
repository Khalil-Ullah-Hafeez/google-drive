import socket

# port to connect at
LISTEN_PORT = 8085

# buffer size
BUFFER_SIZE = 1024

# create socket
client_socket = socket.socket( family = socket.AF_INET, type = socket.SOCK_STREAM, proto = 0 )

try:
    # connect to server
    client_socket.connect( ( '127.0.0.1', LISTEN_PORT ) )

    # ask the user for the file name
    filename = input("Enter the name of the file with extension: ")

    # send the filename to the server
    client_socket.sendall( filename.encode() )

    # receive data from the server
    received_data =  client_socket.recv( BUFFER_SIZE ).decode()

    # print received data
    print( 'DATA FROM SERVER IS' )
    print( '---------------------------' )
    print( received_data )

except Exception as ex:
    print(ex)

# close the socket
client_socket.close()
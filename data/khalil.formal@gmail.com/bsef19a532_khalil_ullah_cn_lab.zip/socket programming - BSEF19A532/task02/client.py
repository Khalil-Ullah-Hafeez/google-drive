import socket

# this task uses an encrytion library to encrypt the data
# run this command to install the library: pip install cryptography
# note: you need to have pip installed to be able to run this command
from cryptography.fernet import Fernet

# key for encrytion
key = b'UmAFE5CUoSabAyeM4Ebnfv7ANgvbfXPmmp1lCpKEPKw='

# create instance
f = Fernet( key )

# port to connect at
LISTEN_PORT = 8085

# buffer size
BUFFER_SIZE = 1024

# create socket
client_socket = socket.socket( family = socket.AF_INET, type = socket.SOCK_STREAM, proto = 0 )

try:
    # connect to server
    client_socket.connect( ( '127.0.0.1', LISTEN_PORT ) )

    # ask the user for the file name
    filename = input("Enter the name of the file with extension: ")

    # open the file
    with open(filename) as file:
        # read the file, encrypt the data and send it to the server
        client_socket.sendall( f.encrypt( file.read().encode() ) )

    # receive data from the server
    received_data =  client_socket.recv( BUFFER_SIZE ).decode()

    # print received data
    print( 'DECODED DATA FROM SERVER IS' )
    print( '---------------------------' )
    print( received_data )

except Exception as ex:
    print(ex)

# close the socket
client_socket.close()
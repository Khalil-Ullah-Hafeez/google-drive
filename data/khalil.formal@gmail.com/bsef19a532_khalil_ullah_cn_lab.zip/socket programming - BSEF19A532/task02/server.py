import socket

# this task uses an encrytion library to encrypt the data
# run this command to install the library: pip install cryptography
# note: you need to have pip installed to be able to run this command
from cryptography.fernet import Fernet

# key for decryption
key = b'UmAFE5CUoSabAyeM4Ebnfv7ANgvbfXPmmp1lCpKEPKw='

# create instance
f = Fernet( key )

# port to listen at
LISTEN_PORT = 8085

# buffer size
BUFFER_SIZE = 1024

# maxmium queue
QUEUE = 1

# create the socket
server_socket = socket.socket( family = socket.AF_INET, type = socket.SOCK_STREAM, proto = 0)

# bind to a port
server_socket.bind( ( '127.0.0.1', LISTEN_PORT ) )

# listen for connections
server_socket.listen( QUEUE )
print( 'The server is listening for connections' )

try:
    # wait for a connection from a client
    client_socket, addr = server_socket.accept()

    # receive data from client
    received_data =  client_socket.recv( BUFFER_SIZE )

    # decode data
    decoded_data = (f.decrypt( received_data ) ).decode()

    # send decoded data back to client
    client_socket.send( decoded_data.encode() )

except Exception as ex:
    print(ex)

# close socket
client_socket.close()
server_socket.close()
import socket

# port to listen at
LISTEN_PORT = 8085

# buffer size
BUFFER_SIZE = 1024

# maxmium queue
QUEUE = 1

# create the socket
server_socket = socket.socket( family = socket.AF_INET, type = socket.SOCK_DGRAM, proto = 0)

# bind to a port
server_socket.bind( ( '127.0.0.1', LISTEN_PORT ) )

# receive data from client
received_data, address =  server_socket.recvfrom( BUFFER_SIZE )

# print received data
print( received_data.decode() )

# send connection acknowledgement
server_socket.sendto( 'This data is sent from the server using TCP'.encode(), address )

# close socket
server_socket.close()
import socket

# port to listen at
LISTEN_PORT = 8085

# buffer size
BUFFER_SIZE = 1024

# maxmium queue
QUEUE = 1

# create the socket
server_socket = socket.socket( family = socket.AF_INET, type = socket.SOCK_STREAM, proto = 0)

# bind to a port
server_socket.bind( ( '127.0.0.1', LISTEN_PORT ) )

# listen for connections
server_socket.listen( QUEUE )
print( 'The server is listening for connections' )

# wait for a connection from a client
client_socket, addr = server_socket.accept()

# receive data from client
received_data =  client_socket.recv( BUFFER_SIZE ).decode()

# print received data
print( received_data )

# send connection acknowledgement
client_socket.send( 'This data is sent from the server using TCP'.encode() )

# close socket
client_socket.close()
server_socket.close()
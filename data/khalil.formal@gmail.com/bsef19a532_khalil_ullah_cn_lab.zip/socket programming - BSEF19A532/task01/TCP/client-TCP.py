import socket

# port to connect at
LISTEN_PORT = 8085

# buffer size
BUFFER_SIZE = 1024

# create socket
client_socket = socket.socket( family = socket.AF_INET, type = socket.SOCK_STREAM, proto = 0 )

try:
    # connect to server
    client_socket.connect( ( '127.0.0.1', LISTEN_PORT ) )

    # send data to the server
    client_socket.sendall( 'This data is sent from the client using TCP'.encode( ) )

    # receive data from the server
    received_data =  client_socket.recv( BUFFER_SIZE ).decode()

    # print received data
    print( received_data )

except:
    print( 'There was an error trying to connect to the server' )

# close the socket
client_socket.close()